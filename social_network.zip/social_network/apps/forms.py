

from django import forms
from .models import Profile
from django.contrib.auth.models import User


class CustomUserForm(forms.ModelForm):
    username=forms.CharField(max_length=30)
    password = forms.CharField(widget=forms.PasswordInput())
    email=forms.EmailField()
    class Meta:
        model=Profile
        fields=['mobile'] #+['username','password']


class OtpForm(forms.ModelForm):
    class Meta:
        model=Profile
        fields=['otp']



class CustomProfileForm(forms.ModelForm):
    class Meta:
        model=Profile
        # fields="__all__"
        exclude=['otp','mobile','user']
        # exclude = ['field1', 'field2'] 



