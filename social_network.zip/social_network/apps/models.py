from django.db import models
from django.contrib.auth.models import AbstractUser
from phonenumber_field.modelfields import PhoneNumberField
from phonenumber_field.widgets import PhoneNumberPrefixWidget
from django.contrib.auth.models import User



class Profile(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    mobile=models.CharField(max_length=20,blank=True,null=True)
    otp=models.CharField(max_length=6,blank=True,null=True)
    bio=models.TextField(blank=True,null=True)
    profileimage=models.ImageField(upload_to='profile_image',default='blank-profile-picture.png',blank=True,null=True)
    location=models.CharField(max_length=100,default='',blank=True,null=True)
    














# class CustomUser(AbstractUser):
#     username=models.CharField(max_length=50,blank=True,null=True)
#     phone_number =PhoneNumberField(unique=True,blank=True,null=True)
    
#     USERNAME_FIELD='phone_number'
#     REQUIRED_FIELDS=('username',)
    
    
#     def __str__(self) -> str:
#         return self.username
    

# class CustomProfile(models.Model):
#     user_name=models.OneToOneField(CustomUser,on_delete=models.CASCADE)
#     bio=models.CharField(max_length=300)
#     first_name=models.CharField(max_length=50,blank=True,null=True)
#     last_name=models.CharField(max_length=50,blank=True,null=True)
#     email=models.EmailField(unique=True,blank=True,null=True)
#     date_of_birth = models.DateField(null=True,blank=True,auto_now_add=True)
#     picture = models.ImageField(upload_to='profile_pics/', blank=True,null=True)

    
#     def __str__(self) -> str:
#         return self.first_name

# # def create_user_customprofile(sender,instance,created,**kwargs):
# #     if created:
# #         CustomProfile.objects.create(user_name=instance)


# # def save_user_customprofile(sender,instance,**kwargs):
# #     instance.customprofile.save()

# post_save.connect(create_user_customprofile,sender=CustomUser)
# post_save.connect(save_user_customprofile,sender=CustomUser)